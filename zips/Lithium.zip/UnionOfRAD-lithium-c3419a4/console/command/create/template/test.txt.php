namespace {:namespace};

use {:use};

class {:class} extends \lithium\test\Unit {

	public function setUp() {}

	public function tearDown() {}

{:methods}
}