namespace {:namespace};

class {:class} extends {:parent} {

{:methods}
}