Layout top.
<?=$this->content(); ?>
Layout bottom.