<?php

require(dirname(__FILE__).'/../application.init.php');

require(LIB_PATH.'jelix-tests/phpunit.inc.php');
