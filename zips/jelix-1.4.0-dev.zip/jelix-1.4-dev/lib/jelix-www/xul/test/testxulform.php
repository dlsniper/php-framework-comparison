<?php
header('Content-type: text/plain;charset=utf-8');
//sleep(2);

echo "ce que je reçoit:\n";

var_export($_POST);

//$chaine = var_export($_POST, true);

//file_put_contents("../../temp/testapp/reception.txt", $chaine);

//phpinfo();
?>
