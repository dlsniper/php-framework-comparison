<?php

$locales = array(

    'title'=>'Bienvenue',
    'instruction'=>'Cliquez sur le bouton "suivant" pour démarrer l\'installation de l\'application',

);
