<?php defined('SYSPATH') or die('No direct script access.');

class Codebench extends Kohana_Codebench {}