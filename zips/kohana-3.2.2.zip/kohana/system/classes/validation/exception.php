<?php defined('SYSPATH') or die('No direct script access.');

class Validation_Exception extends Kohana_Validation_Exception {}
