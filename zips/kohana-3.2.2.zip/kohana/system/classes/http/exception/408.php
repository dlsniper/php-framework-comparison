<?php defined('SYSPATH') or die('No direct script access.');

class HTTP_Exception_408 extends Kohana_HTTP_Exception_408 {}